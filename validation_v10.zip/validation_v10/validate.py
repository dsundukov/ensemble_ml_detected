import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd


def wilson(k, n, z=1.96):
    if n == 0:
        return float("nan"), float("nan")
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, c - h), min(1.0, c + h)


def roc_auc(y, s):
    y, s = np.asarray(y), np.asarray(s, dtype=float)
    pos, neg = s[y == 1], s[y == 0]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    order = np.argsort(np.concatenate([pos, neg]), kind="mergesort")
    ranks = np.empty(len(order))
    allv = np.concatenate([pos, neg])[order]
    i = 0
    while i < len(allv):
        j = i
        while j + 1 < len(allv) and allv[j + 1] == allv[i]:
            j += 1
        ranks[order[i:j + 1]] = (i + j) / 2 + 1
        i = j + 1
    return float((ranks[:len(pos)].sum() - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg)))


def parse_result(v):
    s = str(v).strip().lower()
    if s in ("true", "1", "1.0"):
        return True
    if s in ("false", "0", "0.0"):
        return False
    return None


def metrics(df, min_precision=0.40, min_recall=0.75):
    y = df["label"].astype(int).values
    r = df["result"].map(parse_result)
    out = {"n": int(len(df)), "attacks": int(y.sum()), "benign": int((y == 0).sum()),
           "none_share": round(float(r.isna().mean()), 4)}
    if "score" in df and df["score"].notna().all():
        out["roc_auc"] = round(roc_auc(y, df["score"].values), 4)
    for mode, none_as in (("none_as_benign", False), ("none_as_attack", True)):
        pred = r.where(r.notna(), none_as).astype(bool).values
        tp = int(((pred) & (y == 1)).sum()); fp = int(((pred) & (y == 0)).sum())
        fn = int((~pred & (y == 1)).sum()); tn = int((~pred & (y == 0)).sum())
        p_lo, p_hi = wilson(tp, tp + fp); r_lo, r_hi = wilson(tp, tp + fn); f_lo, f_hi = wilson(fp, fp + tn)
        prec = tp / (tp + fp) if tp + fp else float("nan")
        rec = tp / (tp + fn) if tp + fn else float("nan")
        if prec >= min_precision and rec >= min_recall:
            goal = "подтверждена ДИ" if p_lo >= min_precision and r_lo >= min_recall else "точечно (ДИ ниже цели)"
        else:
            goal = "не достигнута"
        out[mode] = {"TP": tp, "FP": fp, "FN": fn, "TN": tn,
                     "precision": round(prec, 4), "precision_ci95": [round(p_lo, 3), round(p_hi, 3)],
                     "recall": round(rec, 4), "recall_ci95": [round(r_lo, 3), round(r_hi, 3)],
                     "fpr": round(fp / (fp + tn), 4) if fp + tn else None,
                     "fpr_ci95": [round(f_lo, 3), round(f_hi, 3)], "goal": goal}
    return out


def print_metrics(m, title):
    print(f"=== {title}: n={m['n']}, атак={m['attacks']}, безобидных={m['benign']}, доля None={m['none_share']:.3f}"
          + (f", ROC-AUC={m['roc_auc']}" if "roc_auc" in m else ""))
    for mode, name in (("none_as_attack", "None = атака    "), ("none_as_benign", "None = нет атаки")):
        x = m[mode]
        print(f"  {name}: precision {x['precision']:.3f} {x['precision_ci95']} | recall {x['recall']:.3f} "
              f"{x['recall_ci95']} | FPR {x['fpr']} | TP={x['TP']} FP={x['FP']} FN={x['FN']} TN={x['TN']} "
              f"-> цель {x['goal']}")


def run_model(model_dir, data, out):
    sys.path.insert(0, str(Path(model_dir).resolve().parent))
    from ensemble_model import PromptAttackEnsemble
    model = PromptAttackEnsemble(str(model_dir))
    df = pd.read_csv(data)
    rows = [model.predict(str(t)) for t in df["text"]]
    df["result"] = [r["result"] for r in rows]
    df["score"] = [r["score"] for r in rows]
    df["stage"] = [r["stage"] for r in rows]
    df["lang"] = [r["lang"] for r in rows]
    if out:
        df.to_csv(out, index=False)
    return df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred", help="CSV с колонками label, result (True/False/пусто), score")
    ap.add_argument("--model", help="папка ensemble/ (рядом должен лежать ensemble_model.py)")
    ap.add_argument("--data", help="CSV с колонками text, label для прогона модели")
    ap.add_argument("--out", help="куда сохранить предсказания при прогоне модели")
    ap.add_argument("--json", help="куда сохранить метрики в JSON")
    args = ap.parse_args()
    if args.pred:
        df = pd.read_csv(args.pred)
    elif args.model and args.data:
        df = run_model(args.model, args.data, args.out)
    else:
        ap.error("укажите --pred или --model вместе с --data")
    m = metrics(df)
    print_metrics(m, Path(args.pred or args.data).name)
    if "category" in df.columns:
        r = df["result"].map(parse_result)
        y = df["label"].astype(int)
        err = pd.DataFrame({"category": df["category"],
                            "FP": ((r == True) & (y == 0)).astype(int),
                            "FN": ((r == False) & (y == 1)).astype(int),
                            "None": r.isna().astype(int)}).groupby("category").sum()
        err = err[(err > 0).any(axis=1)].sort_values(["FN", "FP"], ascending=False)
        if len(err):
            print("\n  Ошибки по категориям:")
            print(err.to_string())
    if args.json:
        Path(args.json).write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
